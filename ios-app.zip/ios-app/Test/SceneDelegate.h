//
//  SceneDelegate.h
//  Test
//
//  Created by johnnyfranks on 1/12/26.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

